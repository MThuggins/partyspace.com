# PartySpace 🎉

> Find the Perfect Venue for Your Next Event

## Requirements

- **Node.js 24+** — uses native `node:http`, `node:fs`, `node:path` (no build tools needed)

## Quick Start

```bash
# 1. Make sure you're on Node 24
node -v   # should print v24.x.x
# (if not, run: nvm install 24 && nvm use 24)

# 2. Install dependencies
npm install

# 3. Run locally
npm run dev
# → http://localhost:3000
```

## Project Structure

```
partyspace/
├── public/
│   └── index.html       # The full website
├── server.js            # Node 24 HTTP server
├── package.json         # engines: node >=24
├── .nvmrc               # pins Node 24 for nvm users
├── netlify.toml         # Netlify deployment config
└── vercel.json          # Vercel deployment config
```

## Deploy

### Netlify (easiest)
1. Push to GitHub
2. Connect repo at netlify.com → "New site from Git"
3. Build command: _(leave blank)_
4. Publish directory: `public`
5. Node version is set to 24 in `netlify.toml` automatically

### Vercel
1. Push to GitHub
2. Import at vercel.com → "New Project"
3. Node version is set to 24.x in `vercel.json` automatically

### Manual / VPS
```bash
npm start
# Runs on PORT env variable or 3000
```

## Custom Domain
1. Buy your domain at Namecheap or Cloudflare Registrar
2. In Netlify/Vercel dashboard → "Domain settings" → Add custom domain
3. Update your domain's nameservers as instructed — SSL is automatic and free
