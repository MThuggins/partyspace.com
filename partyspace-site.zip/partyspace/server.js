import { createServer } from "node:http";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;

// Minimal static file server using Node 24 native features
// Swap this out for Express or any framework as the app grows
const MIME = {
  ".html": "text/html",
  ".css":  "text/css",
  ".js":   "application/javascript",
  ".json": "application/json",
  ".png":  "image/png",
  ".jpg":  "image/jpeg",
  ".svg":  "image/svg+xml",
  ".ico":  "image/x-icon",
  ".woff2":"font/woff2",
};

const server = createServer((req, res) => {
  // Strip query strings and decode URI
  let pathname = decodeURIComponent(req.url.split("?")[0]);

  // Default to index.html for root and unknown paths (SPA-friendly)
  if (pathname === "/" || !pathname.includes(".")) pathname = "/index.html";

  const filePath = join(__dirname, "public", pathname);
  const ext = pathname.slice(pathname.lastIndexOf("."));

  try {
    const content = readFileSync(filePath);
    res.writeHead(200, {
      "Content-Type": MIME[ext] || "application/octet-stream",
      "Cache-Control": ext === ".html" ? "no-cache" : "public, max-age=31536000",
      "X-Content-Type-Options": "nosniff",
    });
    res.end(content);
  } catch {
    // 404 — fall back to index.html so client-side routing works
    try {
      const fallback = readFileSync(join(__dirname, "public", "index.html"));
      res.writeHead(404, { "Content-Type": "text/html" });
      res.end(fallback);
    } catch {
      res.writeHead(500);
      res.end("Server error");
    }
  }
});

server.listen(PORT, () => {
  console.log(`PartySpace running on http://localhost:${PORT}`);
  console.log(`Node.js ${process.version}`);
});
